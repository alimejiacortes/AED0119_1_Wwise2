# AED0119_1_Wwise2
Cada quien tiene que generar el fork de este repo en su cuenta, clonarlo, modificar la sesión de Wwise agregando un objeto SOUND FX en el Actor Mixer Hierchy, que contenga cualquier sonido no mayor a 3 seg. 
Posteriormente tiene que crear un Pull request, para que yo pueda unificar el trabajo de todos en una sola sesión. 
